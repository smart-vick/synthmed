# SynthMed — Setup & Run Guide

## What's in this folder

```
index.html     ← Frontend (served by the backend)
server.js      ← Express API backend
package.json   ← Node dependencies
README.md      ← This file
```

---

## Quick Start (local development)

### 1. Install Node.js (if you haven't)
Download from https://nodejs.org — version 18 or higher required.

### 2. Install dependencies
Open a terminal in this folder and run:
```bash
npm install
```

### 3. Start the backend
```bash
npm run dev
```

You'll see:
```
  SynthMed API  →  http://localhost:3000
  Health check  →  http://localhost:3000/api/health
  Site          →  http://localhost:3000/index.html
```

### 4. Open your site
Visit **http://localhost:3000/index.html** in your browser.

That's it. The demo generator and contact form both talk to your own backend now.

---

## API Endpoints

| Method | Endpoint                  | What it does                            |
|--------|---------------------------|-----------------------------------------|
| GET    | `/api/health`             | Check if the server is running          |
| POST   | `/api/generate-preview`   | Generate one synthetic patient record   |
| POST   | `/api/sample-request`     | Submit a contact / sample request lead  |
| POST   | `/api/generate-batch`     | Download a small CSV batch (max 50)     |
| GET    | `/api/leads`              | View all leads (requires admin key)     |

### Example: Generate a preview record
```bash
curl -X POST http://localhost:3000/api/generate-preview \
  -H "Content-Type: application/json" \
  -d '{"province": "ON", "conditionCategory": "cardiovascular"}'
```

### Example: Submit a lead
```bash
curl -X POST http://localhost:3000/api/sample-request \
  -H "Content-Type: application/json" \
  -d '{"name":"Dr. Smith","email":"smith@hospital.ca","organization":"Toronto General"}'
```

### Example: Download a batch CSV
```bash
curl -X POST http://localhost:3000/api/generate-batch \
  -H "Content-Type: application/json" \
  -d '{"province":"random","conditionCategory":"diabetes","count":25}' \
  --output synthmed_batch.csv
```

### View leads (dev only)
```bash
curl http://localhost:3000/api/leads \
  -H "x-admin-key: dev-only"
```
Set the `ADMIN_KEY` environment variable to something secret before going to production.

---

## Environment variables

| Variable    | Default     | Description                              |
|-------------|-------------|------------------------------------------|
| `PORT`      | `3000`      | Port the server listens on               |
| `ADMIN_KEY` | `dev-only`  | Key required to access `/api/leads`      |

Set them before starting:
```bash
PORT=8080 ADMIN_KEY=my-secret npm run dev
```

---

## Deploying to production

### Option A — Railway (easiest, free tier)
1. Push this folder to a GitHub repo
2. Go to https://railway.app and connect your repo
3. Set environment variables in the Railway dashboard
4. Railway auto-detects Node and runs `npm start`
5. Update `API_BASE` in `index.html` to your Railway URL

### Option B — Render
1. Push to GitHub
2. Create a new Web Service at https://render.com
3. Build command: `npm install`
4. Start command: `npm start`
5. Set env vars in the Render dashboard

### Option C — VPS (DigitalOcean, Linode, etc.)
```bash
# On the server
git clone your-repo
cd synthmed
npm install
PORT=3000 node server.js

# Keep it running with PM2
npm install -g pm2
pm2 start server.js --name synthmed
pm2 save
```

---

## What's stored where

Right now, leads are stored **in memory** (they reset when the server restarts).

**Step 2** (coming next) adds:
- PostgreSQL database for persistent lead storage
- Email confirmation on form submission
- `POST /api/generate-dataset` for full dataset generation
- CSV file download with expiring signed URLs

---

## Troubleshooting

**"Could not reach the API server" in the demo**
→ Make sure `npm run dev` is running in a terminal
→ Check http://localhost:3000/api/health in your browser

**Form shows error after submitting**
→ Open browser DevTools → Network tab → look for the `/api/sample-request` request
→ Check the terminal where the server is running for error messages

**Port already in use**
```bash
PORT=3001 npm run dev
```
Then update `API_BASE` in `index.html` to `http://localhost:3001`
