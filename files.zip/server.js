import express from "express";
import cors from "cors";
import path from "path";
import { fileURLToPath } from "url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());

// Serve the frontend HTML file
app.use(express.static(__dirname));

// ─── DATA ────────────────────────────────────────────────────────
const PROVINCES = {
  ON: "Ontario",
  BC: "British Columbia",
  AB: "Alberta",
  QC: "Quebec",
  NS: "Nova Scotia",
  MB: "Manitoba",
  SK: "Saskatchewan",
  NB: "New Brunswick",
  NL: "Newfoundland and Labrador",
  PE: "Prince Edward Island",
  YT: "Yukon",
  NT: "Northwest Territories",
  NU: "Nunavut",
};

const CONDITIONS = {
  cardiovascular: [
    {
      icd: "I10",
      diagnosis_label: "Essential Hypertension",
      medication: "Lisinopril 10mg",
      bp_mmhg: "148/92",
      glucose_mmol: 5.2,
      hba1c_pct: 5.4,
    },
    {
      icd: "I25",
      diagnosis_label: "Chronic Ischaemic Heart Disease",
      medication: "Metoprolol 50mg",
      bp_mmhg: "136/84",
      glucose_mmol: 5.8,
      hba1c_pct: 5.6,
    },
    {
      icd: "I48",
      diagnosis_label: "Atrial Fibrillation",
      medication: "Apixaban 5mg",
      bp_mmhg: "132/80",
      glucose_mmol: 5.1,
      hba1c_pct: 5.3,
    },
  ],
  diabetes: [
    {
      icd: "E11",
      diagnosis_label: "Type 2 Diabetes Mellitus",
      medication: "Metformin 500mg",
      bp_mmhg: "138/86",
      glucose_mmol: 9.4,
      hba1c_pct: 8.1,
    },
    {
      icd: "E11.6",
      diagnosis_label: "T2DM with Complications",
      medication: "Empagliflozin 10mg",
      bp_mmhg: "144/90",
      glucose_mmol: 11.2,
      hba1c_pct: 9.3,
    },
  ],
  respiratory: [
    {
      icd: "J44",
      diagnosis_label: "COPD",
      medication: "Tiotropium Inhaler",
      bp_mmhg: "158/94",
      glucose_mmol: 5.9,
      hba1c_pct: 5.7,
    },
    {
      icd: "J45",
      diagnosis_label: "Asthma",
      medication: "Salbutamol Inhaler PRN",
      bp_mmhg: "122/76",
      glucose_mmol: 5.0,
      hba1c_pct: 5.2,
    },
  ],
  "mental-health": [
    {
      icd: "F32",
      diagnosis_label: "Depressive Episode",
      medication: "Sertraline 50mg",
      bp_mmhg: "118/74",
      glucose_mmol: 4.8,
      hba1c_pct: 5.1,
    },
    {
      icd: "F41",
      diagnosis_label: "Anxiety Disorder",
      medication: "Escitalopram 10mg",
      bp_mmhg: "124/78",
      glucose_mmol: 5.0,
      hba1c_pct: 5.2,
    },
  ],
};

const ALL_CONDITIONS = Object.values(CONDITIONS).flat();

// In-memory lead store (replace with Postgres in Step 2)
const leads = [];

// ─── HELPERS ─────────────────────────────────────────────────────
function randomFrom(arr) {
  return arr[Math.floor(Math.random() * arr.length)];
}
function randomInt(min, max) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}
function randomFloat(min, max, decimals = 1) {
  return Number((Math.random() * (max - min) + min).toFixed(decimals));
}
function makePatientId() {
  return `SYN-CA-${String(randomInt(1000, 9999)).padStart(4, "0")}`;
}
function generatePreviewRecord({ province, conditionCategory }) {
  const provinceKeys = Object.keys(PROVINCES);
  const provinceCode =
    province && province !== "random"
      ? province
      : randomFrom(provinceKeys);

  const selectedSet =
    conditionCategory && conditionCategory !== "random"
      ? CONDITIONS[conditionCategory] || ALL_CONDITIONS
      : ALL_CONDITIONS;

  const condition = randomFrom(selectedSet);

  return {
    patient_id: makePatientId(),
    age: randomInt(28, 84),
    sex: Math.random() > 0.48 ? "Female" : "Male",
    province_code: provinceCode,
    province: PROVINCES[provinceCode],
    icd10_primary: condition.icd,
    diagnosis_label: condition.diagnosis_label,
    medication: condition.medication,
    bmi: randomFloat(18, 36),
    bp_mmhg: condition.bp_mmhg,
    glucose_mmol: condition.glucose_mmol,
    hba1c_pct: condition.hba1c_pct,
    los_days: randomInt(2, 12),
    readmit_30d: Math.random() > 0.72,
    synthetic: true,
  };
}

// ─── ROUTES ──────────────────────────────────────────────────────

// Health check
app.get("/api/health", (_req, res) => {
  res.json({
    ok: true,
    service: "synthmed-api",
    uptime_seconds: Math.floor(process.uptime()),
    leads_count: leads.length,
  });
});

// Submit contact / sample request
app.post("/api/sample-request", (req, res) => {
  const { name, email, organization, role, message } = req.body ?? {};

  if (!name || !email || !organization) {
    return res.status(400).json({
      ok: false,
      error: "name, email, and organization are required",
    });
  }

  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    return res.status(400).json({
      ok: false,
      error: "Invalid email address",
    });
  }

  const lead = {
    id: leads.length + 1,
    name: String(name).trim(),
    email: String(email).trim().toLowerCase(),
    organization: String(organization).trim(),
    role: role ? String(role).trim() : "",
    message: message ? String(message).trim() : "",
    created_at: new Date().toISOString(),
    status: "new",
  };

  leads.push(lead);

  console.log(`[lead] #${lead.id} — ${lead.name} <${lead.email}> @ ${lead.organization}`);

  return res.json({
    ok: true,
    message: "Sample request received. We'll be in touch within 24 hours.",
    lead_id: lead.id,
  });
});

// Generate a single preview record
app.post("/api/generate-preview", (req, res) => {
  const { province = "random", conditionCategory = "random" } = req.body ?? {};

  const record = generatePreviewRecord({ province, conditionCategory });

  return res.json({
    ok: true,
    record,
    metadata: {
      generator_version: "v1",
      validated: true,
      generated_at: new Date().toISOString(),
    },
  });
});

// Generate a batch CSV (small demo — up to 50 records)
app.post("/api/generate-batch", (req, res) => {
  const {
    province = "random",
    conditionCategory = "random",
    count = 10,
  } = req.body ?? {};

  const safeCount = Math.min(Math.max(parseInt(count) || 10, 1), 50);
  const records = Array.from({ length: safeCount }, () =>
    generatePreviewRecord({ province, conditionCategory })
  );

  const headers = Object.keys(records[0]).join(",");
  const rows = records.map((r) => Object.values(r).join(",")).join("\n");
  const csv = `${headers}\n${rows}`;

  res.setHeader("Content-Type", "text/csv");
  res.setHeader(
    "Content-Disposition",
    `attachment; filename="synthmed_preview_${safeCount}records.csv"`
  );
  res.send(csv);
});

// View all leads (dev only — protect this in production)
app.get("/api/leads", (req, res) => {
  const authHeader = req.headers["x-admin-key"];
  if (authHeader !== (process.env.ADMIN_KEY || "dev-only")) {
    return res.status(403).json({ ok: false, error: "Forbidden" });
  }
  res.json({ ok: true, count: leads.length, leads });
});

// ─── START ───────────────────────────────────────────────────────
app.listen(PORT, () => {
  console.log(`\n  SynthMed API  →  http://localhost:${PORT}`);
  console.log(`  Health check  →  http://localhost:${PORT}/api/health`);
  console.log(`  Site          →  http://localhost:${PORT}/index.html\n`);
});
